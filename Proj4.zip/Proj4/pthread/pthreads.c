/*
 * CIS 520 - Operating Systems
 * Project 4 - Parallel Computing
 * Dalton Hahn, Lane Evans, Olivia Baalman
 *
 * PThreads Solution
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <pthread.h>

#define WIKI_LINE_SIZE 3000 
#define WIKI_LINE_ELEMS 1000
#define NUM_THREADS 7 



// Global variable for list of wikipedia entries
char **wiki_entries;

// Global variable for calculated substrings
char **substrings;


void print_results()
{
  int i;
  for(i=1; i<WIKI_LINE_ELEMS; i++)
  {
    printf("[%d,%d]: %s\n", i-1, i, substrings[i-1]);
  }
}


char* calc_substring(char* line1, char* line2)
{
  int m = strlen(line1);
  int n = strlen(line2);

  int **LCSuff = (int **)malloc((m + 1)*sizeof(int *));
  int a = 0;
  for(a=0; a < m+1; a++)
  {
    LCSuff[a] = (int *)malloc((n+1)*sizeof(int));
  }
  int len = 0;
  int row, col;
  
  int i;
  for(i=0; i<= m; i++)
  {
    int j;
    for(j=0; j<=n; j++)
    {
      if(i==0 || j==0)
      {
        LCSuff[i][j] = 0;
      }
      else if(line1[i-1] == line2[j-1])
      {
        LCSuff[i][j] = LCSuff[i-1][j-1] + 1;
        if(len < LCSuff[i][j])
        {
          len = LCSuff[i][j];
          row = i;
          col = j;
        }
      }
      else
      {
        LCSuff[i][j] = 0;
      }
    }
  }
    
  if(len == 0)
  {
    printf("No Common Substring");
    return;
  }
      
  char *resultStr;
  resultStr = malloc(len+1);
  resultStr[len] = '\0';

  while(LCSuff[row][col] != 0)
  {
    resultStr[--len] = line1[row-1];
    row--;
    col--;
  }

  for(a=0; a < m+1; a++)
  {
    free(LCSuff[a]);
  }
  free(LCSuff);
  return resultStr;
}


void substring_write(void *myID)
{ 
  //Allocate space for all of the wiki lines, and also allocate space
  //for each line as they are read from the file
  substrings = malloc((WIKI_LINE_ELEMS)*sizeof(char*));
  char *longest_sub;
  longest_sub = malloc((WIKI_LINE_SIZE)*sizeof(char));

  //Need to add code here to divide the workspace
  int startPos = ((int) myID) * (WIKI_LINE_ELEMS / NUM_THREADS);
  int endPos;
  if((int) myID + 1 == NUM_THREADS)
  {
    endPos = WIKI_LINE_ELEMS;
  }
  else
  {
    endPos = startPos + (WIKI_LINE_ELEMS / NUM_THREADS) + (WIKI_LINE_ELEMS % NUM_THREADS);
  }

  if(startPos != 0)
  {
    startPos--;
  }

  int i;
  for(i =startPos+1; i <endPos; i++)
  {
    longest_sub = calc_substring(wiki_entries[i-1], wiki_entries[i]);
    substrings[i-1] = malloc((WIKI_LINE_SIZE)*sizeof(char));
    strcpy(substrings[i-1], longest_sub);
  }
}


int file_read()
{
  FILE *file = fopen("/homes/dan/625/wiki_dump.txt", "r");

  if(file == NULL)
  {
    printf("Failed to open file\n");
    return -1;
  }
  
  //Allocate space for all of the wiki lines, and also allocate space
  //for each line as they are read from the file
  wiki_entries = malloc((WIKI_LINE_ELEMS)*sizeof(char*));
  char *line;
  line = malloc((WIKI_LINE_SIZE)*sizeof(char));

  //Read the lines from the file and populate the wiki_entries
  //global variable which is a char** 
  int line_num = 0;
  while ( !feof(file) && line_num <=WIKI_LINE_ELEMS)
  {
    if (fgets(line,WIKI_LINE_SIZE,file) != NULL)
    {
      wiki_entries[line_num] = malloc((WIKI_LINE_SIZE)*sizeof(char));
      strcpy(wiki_entries[line_num], line);
      line_num++;
    }
  }
  fclose(file);
  return 0;
}

int main()
{
  int myVersion = 1;
  clock_t begin = clock();

  /*************/
  int i, rc;
  pthread_t threads[NUM_THREADS];
  pthread_attr_t attr;
  void *status;

  /* Initialize and set thread detached attribute */
  pthread_attr_init(&attr);
  pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
  /**************/


  printf("DEBUG: starting loop on %s\n", getenv("HOST"));
  //Serial
  file_read();


  //PThread stuff

  for (i = 0; i < NUM_THREADS; i++ ) 
  {
    rc = pthread_create(&threads[i], &attr, substring_write, (void *)i);
    if (rc) 
    {
      printf("ERROR; return code from pthread_create() is %d\n", rc);
      exit(-1);
    }
  }
   /**************/
  /* Free attribute and wait for the other threads */
  pthread_attr_destroy(&attr);
  for(i=0; i<NUM_THREADS; i++) 
  {
    rc = pthread_join(threads[i], &status);
    if (rc) 
    {
      printf("ERROR; return code from pthread_join() is %d\n", rc);
      exit(-1);
    }
  }
  /**********/


  //Serial
  print_results();

 
  clock_t end = clock();
  double elapsedTime = ((double)end - (double)begin) / CLOCKS_PER_SEC;
  
  printf("DATA, %d, %s, %f\n", myVersion, getenv("NSLOTS"),  elapsedTime);

  /*****/
  pthread_exit(NULL);
  /******/
  
  return 0;
}
